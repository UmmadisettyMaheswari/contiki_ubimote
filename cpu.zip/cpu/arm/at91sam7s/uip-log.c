#include <stdio.h>

void uip_log(char *msg)
{
  printf("uip: %s\n", msg);
}
