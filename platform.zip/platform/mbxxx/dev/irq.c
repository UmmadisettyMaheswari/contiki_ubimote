/**
 * \addtogroup mbxxx-platform
 *
 * @{
 */
void
irq_init(void)
{
}

/** @} */
