This directory contains the contiki driver for the LED driver for the dongle.

Mapping of LEDs on JN516x Dongle:
    leds.h          led on dongle:
    LEDS_RED        Red LED
    LEDS_GREEN      Green LED
Note: Only one LED can be switch on at the same time


