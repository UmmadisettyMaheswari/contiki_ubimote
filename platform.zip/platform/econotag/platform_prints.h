void print_processes(struct process * const processes[]);
void print_netstack(void);
void print_lladdrs(void);
