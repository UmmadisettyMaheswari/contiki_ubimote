#define QUEUEBUF_CONF_STATS 1
#define RESOLV_CONF_SUPPORTS_MDNS                0
#define COOJA_MTARCH_STACKSIZE                   4096

#undef UIP_CONF_MAX_ROUTES
#define UIP_CONF_MAX_ROUTES                      3
#undef NBR_TABLE_CONF_MAX_NEIGHBORS
#define NBR_TABLE_CONF_MAX_NEIGHBORS             3
